import os
import json
from flask import Flask, request, render_template, redirect, url_for, send_from_directory
from lib.upload_file import uploadfile
from main import *


class CustomFlask(Flask):
    jinja_options = Flask.jinja_options.copy()
    jinja_options.update(dict(
        variable_start_string='%%',  # Default is '{{', I'm changing this because Vue.js uses '{{' / '}}'
        variable_end_string='%%',
    ))
 
app = CustomFlask(__name__)

app.config['UPLOAD_FOLDER'] = 'data/'
app.config['MAX_CONTENT_LENGTH'] = 1000 * 1024 * 1024

ALLOWED_EXTENSIONS = set(['tmp','edf','npy','mat'])
IGNORED_FILES = set(['.gitignore'])
global input_data

def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def infer(filename,channel_system, Unit,channel_idx, task):

    #　channel_system = 'sleep-edfx'
    #　channel_system = 'Physionet'
    # Unit = 'V'
    # Unit = 'uV'
    data = import_file(filename, channel_system, unit=Unit)

    # channel_idx = [0, 1, 2]
    # channel_idx = [0, 1, 2, 3, 4, 5, 6]
    # channel_idx = [0, 1, 2, 3, 4, 5, 6, 7, 9, 10]
    result = run(channel_system, data, channel_idx, task)

    time = []
    if(len(result) == 0 or result["code"] == -1):
        return {"code":-1,"value":result.tolist(),'time':time}
    if(result["type"] == "stage"):
        for i in range(len(result["pred_stage"])):
            seconds = i*30
            m, s = divmod(seconds, 60)
            h, m = divmod(m, 60)
            time.append("{0}:{1:02d}:{2:02d}".format(h, m, s))
        data = {"code":0,"y":result["pred_stage"].tolist(),'x':time}
        return data
    # elif(result["type"] == "apnea"):
    #     for i in range(len(result["pred_apnea"])):
    #         seconds = i*30
    #         m, s = divmod(seconds, 60)
    #         h, m = divmod(m, 60)
    #         time.append("{0}:{1:02d}:{2:02d}".format(h, m, s))
    #     data = {"code":0,"value":result["pred_apnea"],'time':time}
    #     return data        


@app.route("/predictAPI", methods=['POST'])
def predictAPI():
    if request.method == 'POST':
        data = request.get_json(silent=True)
        #print(data['filename'],data['channel_system'],data['Unit'],data['channel_idx'],data['task']) #123
        result = infer("./data/" + data['filename'],data['channel_system'],data['Unit'],data['channel_idx'],data['task'])
        return json.dumps(result)


@app.route("/upload", methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        files = request.files['file']
        if files:
            if os.path.splitext(files.filename)[-1] == '.edf':
                filename = "temp.edf"
            elif os.path.splitext(files.filename)[-1] == '.mat':
                filename = "temp.mat"
            elif os.path.splitext(files.filename)[-1] == '.npy':
                filename = "temp.npy"

            mime_type = files.content_type
            if not allowed_file(files.filename):
                result = uploadfile(name=filename, type=mime_type, size=0, not_allowed_msg="File type not allowed")

            else:
                # save file to disk
                uploaded_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                files.save(uploaded_file_path)
                
                # get file size after saving
                size = os.path.getsize(uploaded_file_path)

                # return json for js call back
                result = uploadfile(name=filename, type=mime_type, size=size)
                channel_system = 'Physionet'

                # Choose the unit:
                # Unit = 'V'
                Unit = 'uV'

                # 2.
                # upload file:
                # file = 'Input_files/SC4002E0-PSG.edf'
                file = 'Input_files/tr03-0005.mat'
                # file = 'Input_files/tr03-0005.npy'
                #input_data = import_file(result.get_file()['url'],channel_system, unit=Unit)
            if os.path.splitext(files.filename)[-1] == '.edf':               
                edf_data = edf_info(result.get_file()['url'])
                return json.dumps({'code':0,'filename':filename,'edf_data':edf_data,"type":"edf"})
            # edf_info(result.get_file()['url'])
            # if(inferdata["code"] == -1):
            #     return json.dumps({"code":-1})
            # return json.dumps({"code":0,"x":inferdata['time'],"y":list(inferdata['value'])})
            # # return json.dumps({"code":0,"x":[
            # #             '0:00', '1:00', '2:00', '3:00',
            # #             '4:00', '5:00', '6:00', '7:00', '8:00'
            # #         ],"y":[4, 4, 4, 3, 4, 3, 2, 1, 4]})

    return json.dumps({'code':0,'filename':filename,"type":"other"})


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(host="0.0.0.0",debug=True, port=9191)
