# Readme
更新时间：2022-03-29 00:33

## apnea任务、标准结果进行比较暂未实现
* 前端 
    * Vue2
    * Element UI
    * Axios
    * Vue-Echart

* 后端
    * Flask (建议用最新版，版本号小于1的无法正常使用)
   

* 使用方法
  - 执行`python .\app.py`，在提示
`* Running on http://0.0.0.0:9191/ (Press CTRL+C to quit)`
后即启动成功。  
  - 浏览器打开链接`http://127.0.0.1:9191/`
