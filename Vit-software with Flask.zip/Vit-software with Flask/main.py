import scipy
import torch
import mne
import os
import numpy as np
import pandas as pd
import apnea
import cv2


def import_edf(edf_file, frequency, show_channel=True):
    # show_channel: tell the user about the channel's name in his/her file
    # frequency: 100Hz or 200Hz

    raw_data = mne.io.read_raw_edf(edf_file)

    if abs(raw_data.info['sfreq'] - frequency) > 1e-6:
        # frequency needs to be changed into 100Hz
        raw_data = raw_data.resample(frequency)

    if show_channel:
        print(raw_data.info['ch_names'])

    raw_data = raw_data.get_data()
    return raw_data

def edf_info(edf_file):
    raw_data = mne.io.read_raw_edf(edf_file)
    try:
        return {'raw_data': raw_data.info['ch_names'], 'ch_index': {"EEG-Fpz-Cz": raw_data.info['ch_names'].index("EEG Fpz-Cz"), "EEG-Pz-Oz": raw_data.info['ch_names'].index("EEG Pz-Oz"), "EOG-horizontal": raw_data.info['ch_names'].index("EOG horizontal")}}
    except:
        return {'raw_data': raw_data.info['ch_names'], 'ch_index': {"EEG-Fpz-Cz": 0, "EEG-Pz-Oz": 1, "EOG-horizontal": 2}}


def import_file(file_name, channel_system, unit='V'):
    # file_type: .edf (sleep-edfx) or .mat (Physionet 2018 challenge) or .npy
    # channel_system
    if channel_system == 'sleep-edfx':
        frequency = 100
    elif channel_system == 'Physionet':
        frequency = 200
    else:
        print('Not supported channels system')
        return -1

    # unit: 'V' or 'uV'

    if os.path.splitext(file_name)[-1] == '.edf':
        data = import_edf(file_name, frequency, show_channel=True)

    elif os.path.splitext(file_name)[-1] == '.mat':
        data = scipy.io.loadmat(file_name)['val']

    elif os.path.splitext(file_name)[-1] == '.npy':
        data = np.load(file_name)

    else:
        print("Not supported file type")
        return -1

    if unit == 'V':
        data = data * 1e6

    return data


def anchor(ori, ref):
    d0 = ori.shape[0]
    d1 = ori.shape[1]
    ref = cv2.resize(ref, (d1, d0), interpolation=cv2.INTER_AREA)
    ori_new = ori.copy()
    for i in range(d0):
        ori_new[i, np.argsort(ori[i, :])] = ref[i, :]
    return ori_new


def predict(data, channel_idx, channel_system):
    # channel_idx: correspond to ['EEG Fpz-Cz', 'EEG Pz-Oz', 'EOG horizontal'] (SYSTEM of sleep-edfx)
    # ['F3-M2', 'F4-M1', 'C3-M2', 'C4-M1', 'O1-M2', 'O2-M1', 'E1-M2'] (SYSTEM of Physionet Challenge)

    data = data[channel_idx, :]

    channel_idx.sort()

    if channel_system == 'Physionet':
        ref = np.load('model_param/ref555_13c.npy')[channel_idx, :]
        data = anchor(data, ref)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    from Models import model

    if channel_system == 'sleep-edfx':
        channel_list = ['F', 'P', 'O']
        dm = 3000
        model = model(image_size=dm, patch_size=100, N_chn=len(channel_idx), depth=24, drop=0.1).to(device)

    elif channel_system == 'Physionet':
        channel_list = ['F3-M2', 'F4-M1', 'C3-M2', 'C4-M1', 'O1-M2', 'O2-M1', 'E1-M2']
        dm = 6000
        model = model(image_size=dm, patch_size=200, N_chn=len(channel_idx), depth=6, drop=0.3).to(device)

    else:
        print("Not supported channel system")

    use_channel = []

    for i in range(len(channel_idx)):
        use_channel.append(channel_list[channel_idx[i]])

    param_file = './model_param/' + '_'.join(channel_list) + '.pth'  # eg.: F_P_O.pth / F_P.pth / F_O.pth / F.pth

    checkpoint = torch.load(param_file)
    model.load_state_dict(checkpoint['ViT'])

    d1 = data.shape[1] // dm  # number of 30s epochs
    data = data[:, :d1 * dm]
    data = data.reshape((-1, d1, dm))
    data = np.transpose(data, (1, 0, 2))

    input = torch.from_numpy(data).to(device)
    input = input.to(torch.float32)

    batch_size = 100
    num_epoch = d1 // batch_size
    with torch.no_grad():
        for epoch in range(num_epoch):
            tmp_input = input[epoch * batch_size:(epoch + 1) * batch_size, :, :]
            tmp = model(tmp_input)
            if epoch == 0:
                outputs = tmp
            else:
                outputs = torch.cat([outputs, tmp], dim=0)

        tmp_input = input[num_epoch * batch_size:d1, :, :]
        tmp = model(tmp_input)
        outputs = torch.cat([outputs, tmp], dim=0)

    _, prediction = outputs.max(dim=1)

    return prediction.cpu().numpy()


def test(prediction, labels):
    dict = {'W': 0, 'N1': 1, 'N2': 2, 'N3': 3, 'REM': 4}

    l = labels.iloc[:, 0].tolist()
    new_l = [dict[i] for i in l]

    labels = np.array(new_l)

    d1 = labels.shape[0]
    prediction = prediction[:d1]

    correct = np.sum(prediction == labels)
    precision = correct / d1
    return precision


def run(channel_system, data, channel_idx, task, label_file=None):
    # channel_system: sleep-edfx or Physionet

    # Unit: V or uV

    # file: e.g. 'Input_files/SC4002E0-PSG.edf' / 'Input_files/tr03-0005.npy'

    # channel_idx: correspond to ['EEG Fpz-Cz', 'EEG Pz-Oz', 'EOG horizontal'] (SYSTEM of sleep-edfx)
    #     # ['F3-M2', 'F4-M1', 'C3-M2', 'C4-M1', 'O1-M2', 'O2-M1', 'E1-M2',
    #     'Chin1-Chin2', 'CHEST', 'AIRFLOW'] (SYSTEM of Physionet Challenge)

    # task: stage or apnea

    # label_file: No file as default (Do not do test), if not none, do test for stage only

    if task == 'stage':
        pred_stage = predict(data, channel_idx, channel_system)

        return {'code':"0",'type':"stage","pred_stage":pred_stage}

    elif task == 'apnea':
        if channel_system != 'Physionet':
            print("Channel System other than Physionet is not supported to do apnea prediction")
            return {'code':"-1",'msg':"Channel System other than Physionet is not supported to do apnea prediction"}

        pred_apnea = apnea.run(channel_idx, data)
        return {'code':"0",'type':"apnea","pred_apnea":pred_apnea,"unique":np.unique(pred_apnea)}      

        # if label_file != None:
        #     print("We do not support the test of apnea prediction currently.")
        #     return -1

    if label_file:
        labels = pd.read_table(label_file, header=None)
        precision = test(pred_stage, labels)
        print("%.3f%% labels are correctly predicted" % (precision * 100))


if __name__ == '__main__':
    # 1.
    # Choose the channel_system:
    #channel_system = 'sleep-edfx'
    channel_system = 'Physionet'

    # Choose the unit:
    #Unit = 'V'
    Unit = 'uV'

    # 2.
    # upload file:
    #file = 'Input_files/SC4002E0-PSG.edf'
    file = 'Input_files/tr03-0005.mat'
    #file = 'Input_files/tr03-0005.npy'

    data = import_file(file, channel_system, unit=Unit)

    # 3.
    # Choose the channel_idx:
    #channel_idx = [0, 1, 2]
    #channel_idx = [0, 1, 2, 3, 4, 5, 6]
    channel_idx = [0, 1, 2, 3, 4, 5, 6, 7, 9, 10]

    # 4.
    # run predict:
    #run(channel_system, data, channel_idx, task='stage')
    run(channel_system, data, channel_idx, task='apnea')

    # 5.
    # run predict and Compare with the gold standard
    # label_file = 'label_files/SC4002EC-Hypnogram.txt'
    #
    # run(channel_system, data, channel_idx, 'stage', label_file)